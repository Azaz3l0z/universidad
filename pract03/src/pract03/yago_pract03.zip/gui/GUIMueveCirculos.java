package pract03.gui;

import pract03.modelo.Circulo;
import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Programa principal que permite dibujar y mover circulos
 * en una ventana.
 * 
 * @author Metodos de Programacion (UC) y Yago Hernandez Garcia
 * @version feb-2021
 */
public class GUIMueveCirculos {
	// dimensiones de la ventana
	private static final int ANCHO_VENTANA_PIXELS = 400;
	private static final int ALTO_VENTANA_PIXELS = 500;

	// intervalo de refresco (en segundos)
	private static final int FPS = 60;
	private static final double INTERVALO_REFRESCO = (double)1/FPS;

	/**
	 * Programa principal.
	 * 
	 * @param args argumentos del main (no usados).
	 */
	public static void main(String[] args) {
		// crea la ventana de dibujo.
		VentanaCirculos ventanaCirculos =
				new VentanaCirculos(ANCHO_VENTANA_PIXELS, ALTO_VENTANA_PIXELS);

		// Variables utiles
		int n_circulos = 10;
		int max_r = 40;
		Circulo[] circulos = new Circulo[n_circulos];
		Color[] colores = {Color.red, Color.pink, Color.orange, Color.magenta};

		int randRadius[] = new int[n_circulos];
		double randXs[] = new double[n_circulos];
		double randYs[] = new double[n_circulos];

		// crea un array de radios aleatorios
		for (int k = 0; k < n_circulos; k++) {
			randRadius[k] = ThreadLocalRandom.current().nextInt(20, max_r);
		}

		// crea circulos aleatorios que no se solapan
		for (int k = 0; k < n_circulos; k++) {
			boolean overlap = true;
			double randX = 0;
			double randY = 0;
			while (overlap) {
				overlap = false;
				randX = (double)ThreadLocalRandom.current().nextInt(randRadius[k], 
						ANCHO_VENTANA_PIXELS-(int)randRadius[k]);
				randY = (double)ThreadLocalRandom.current().nextInt(randRadius[k], 
						ANCHO_VENTANA_PIXELS-(int)randRadius[k]);

				for (int i = 0; i < n_circulos; i++) {
					double dist = Math.hypot(randX-randXs[i], randY-randYs[i]);
					if (dist > (double)(randRadius[k] + randRadius[i])) {
						overlap = false;
					} else {
						overlap = true;
						break;
					}
				}
			}
			randXs[k] = randX;
			randYs[k] = randY;	
		}

		for (int k = 0; k < n_circulos; k++) {
			int randColor = ThreadLocalRandom.current().nextInt(0, colores.length);
			double randVelX = (double)ThreadLocalRandom.current().nextInt(-60, 60);
			double randVelY = (double)ThreadLocalRandom.current().nextInt(-60, 60);
			circulos[k] = new Circulo(randRadius[k], randXs[k], randYs[k], colores[randColor]);
			circulos[k].asignaVelocidad(randVelX, randVelY);
		}


		for (Circulo c : circulos) {
			ventanaCirculos.anhadeCirculo(c);
		}
		double duration = 60;
		double t = 0;
		

		while(t < duration) {
			// Movemos los circulos
			ventanaCirculos.redibuja(INTERVALO_REFRESCO);
			t += INTERVALO_REFRESCO;		
		}
		
		
	}

}
