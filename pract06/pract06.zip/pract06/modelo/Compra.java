package pract06.modelo;

/**
 * Compra realizada en una cadena de tiendas.
 * 
 * @author  Metodos de Programacion (UC) y <TODO: nombre alumno>
 * @version mar-22
 */
public class Compra {
	// TODO: atributos
	
	// TODO: constructor que recibe como parametros el nombre del producto y
	//       el precio
	
	// TODO: metodos observadores
}
