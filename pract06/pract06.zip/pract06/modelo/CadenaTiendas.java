package pract06.modelo;

/**
 * Cadena de tiendas con tarjetas de descuento.
 * 
 * @author  Metodos de Programacion (UC) y <TODO: nombre alumno>
 * @version mar-22
 */
public class CadenaTiendas {
	// TODO: atributos
		
	/**
	 * Anhade una tarjeta.
	 * @param tarjeta tarjeta a anhadir.
	 */
	public void anhadeTarjeta(Tarjeta tarjeta) {
		// TODO
	}
	
	/**
	 * Registra una compra para la tarjeta con el codigo indicado.
	 * @param codTarjeta codigo de la tarjeta a la que asignar la compra.
	 * @param compra compra realizada.
	 * @return true si la compra ha sido asignada con exito y false si no
	 * existe ninguna tarjeta con ese codigo.
	 */
	public boolean registraCompra(String codTarjeta, Compra compra) {
		// TODO
		return false;
	}

	/**
	 * Busca la tarjeta con el codigo indicado.
	 * @param codTarjeta codigo de la tarjeta buscada.
	 * @return la tarjeta con el codigo indicado o null si no existe ninguna
	 * tarjeta con ese codigo.
	 */
	public Tarjeta buscaTarjeta(String codTarjeta) {
		// TODO
		return null;
	}
	
	/**
	 * Retorna la compra que ocupa la posicion indicada en la tarjeta
	 * correspondiente al codigo pasado como parametro.
	 * @param codTarjeta codigo de la tarjeta en la que buscar la compra.
	 * @param posCompra posicion de la compra en el historico de compras de
	 * la tarjeta.
	 * @return la compra buscada o null si no existe ninguna tarjeta con el codigo
	 * indicado o si la posicion no corresponde a ninguna compra.
	 */
	public Compra buscaCompraDeTarjeta(String codTarjeta, int posCompra) {
		// TODO
		return null;
	}

}
