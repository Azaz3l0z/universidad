package pract06.modelo;

/**
 * Tarjeta de descuento.
 * 
 * @author  Metodos de Programacion (UC) y <TODO: nombre alumno>
 * @version mar-22
 */
public class Tarjeta {
	// TODO: atributos

	/**
	 * Construye una tarjeta.
	 * @param dni DNI de la tarjeta a crear.
	 */
	public Tarjeta(String dni) {
		// TODO. Usa un atributo estatico para ir asignando codigos a las
		// tarjetas (ver el ejemplo de la clase Coche en la diapositiva 42 de
		// los apuntes del Tema 2)
	}

	/**
	 * Retorna el DNI del propietario de la tarjeta.
	 * @return el DNI del propietario de la tarjeta.
	 */
	public String dni() {
		// TODO
		return null;
	}

	/**
	 * Retorna el codigo de la tarjeta.
	 * @return el codigo de la tarjeta.
	 */
	public String codigo() {
		// TODO
		return null;
	}

	/**
	 * Retorna los puntos de descuento acumulados.
	 * @return los puntos de descuento acumulados.
	 */
	public int puntosAcumulados() {
		// TODO
		return -1;
	}

	/**
	 * Registra una compra en la tarjeta acumulando los puntos que
	 * correspondan en funcion de su importe.
	 * @param compra compra a registrar.
	 */
	public void registraCompra(Compra compra) {
		// TODO
	}

	/**
	 * Retorna la compra que ocupa en el historico la posicion indicada.
	 * @param posCompra posicion en el historico de la compra buscada.
	 * @return la compra buscada o null si la posicion no corresponde a ninguna
	 * compra
	 */
	public Compra compraEnPos(int posCompra) {
		// TODO
		return null;
	}


}
